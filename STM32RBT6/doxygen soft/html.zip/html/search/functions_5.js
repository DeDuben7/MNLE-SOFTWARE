var searchData=
[
  ['ym_5fnote_5foff_178',['YM_NOTE_OFF',['../_y_m3812_8c.html#aa2d2c50a5c04ee50a278a71fd4f6b06f',1,'YM_NOTE_OFF(uint8_t Key_Number, uint8_t Velocity):&#160;YM3812.c'],['../_y_m3812_8h.html#a71a891a56dae6a5ce236fd50a415c4f2',1,'YM_NOTE_OFF(uint8_t KEY_NUMBER, uint8_t VELOCITY):&#160;YM3812.c']]],
  ['ym_5fnote_5fon_179',['YM_NOTE_ON',['../_y_m3812_8c.html#ac424d9bcb2cd5d53ae5bcf7ce289d25f',1,'YM_NOTE_ON(uint8_t VCH_Num):&#160;YM3812.c'],['../_y_m3812_8h.html#ac424d9bcb2cd5d53ae5bcf7ce289d25f',1,'YM_NOTE_ON(uint8_t VCH_Num):&#160;YM3812.c']]],
  ['ym_5fpitch_180',['YM_PITCH',['../_y_m3812_8c.html#a77cfb7df1776186a6a17cf8e1d98084e',1,'YM_PITCH(uint8_t KeyNumber, uint8_t Velocity):&#160;YM3812.c'],['../_y_m3812_8h.html#a77cfb7df1776186a6a17cf8e1d98084e',1,'YM_PITCH(uint8_t KeyNumber, uint8_t Velocity):&#160;YM3812.c']]],
  ['ym_5freset_181',['YM_RESET',['../_y_m3812_8c.html#aecfbf9bc7e2207dddc36a93ca634920a',1,'YM_RESET():&#160;YM3812.c'],['../_y_m3812_8h.html#aecfbf9bc7e2207dddc36a93ca634920a',1,'YM_RESET():&#160;YM3812.c']]],
  ['ym_5fset_5fdef_182',['YM_SET_Def',['../_y_m3812_8c.html#a300b8fa1f5b4376a379284292147e107',1,'YM_SET_Def():&#160;YM3812.c'],['../_y_m3812_8h.html#a300b8fa1f5b4376a379284292147e107',1,'YM_SET_Def():&#160;YM3812.c']]],
  ['ym_5fwrite_5fdatabus_183',['YM_WRITE_Databus',['../_y_m3812_8c.html#ab11e583d89cc051780fd02df2a24b450',1,'YM_WRITE_Databus(uint8_t chip, uint8_t address, uint8_t data):&#160;YM3812.c'],['../_y_m3812_8h.html#aae4cd4956a9038bd9791b9f92e20ed9b',1,'YM_WRITE_Databus(uint8_t chips, uint8_t adress, uint8_t data):&#160;YM3812.c']]],
  ['ym_5fwritebits_184',['YM_WriteBits',['../_y_m3812_8c.html#a56986b4b02f998b54594aff9be5beb25',1,'YM_WriteBits(uint8_t data):&#160;YM3812.c'],['../_y_m3812_8h.html#a56986b4b02f998b54594aff9be5beb25',1,'YM_WriteBits(uint8_t data):&#160;YM3812.c']]]
];
