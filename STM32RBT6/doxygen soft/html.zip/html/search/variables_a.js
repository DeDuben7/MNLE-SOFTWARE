var searchData=
[
  ['octave_211',['Octave',['../structp_v_c_h.html#aa9d1b2fc2b32fbbf2c260df5b4d7e7df',1,'pVCH']]],
  ['op1_212',['OP1',['../structp_c_c_h.html#a3f5f8861c6a820bb9e71ecf77a568cf1',1,'pCCH::OP1()'],['../_y_m3812_8c.html#a182559a6e69f12db7f4e2a2e6139a171',1,'op1():&#160;YM3812.c']]],
  ['op2_213',['OP2',['../structp_c_c_h.html#abb513cdab63eb1e297a16b9c6e40235a',1,'pCCH::OP2()'],['../_y_m3812_8c.html#a56be4ec9aa652b03c2647e975ef4d935',1,'op2():&#160;YM3812.c']]],
  ['opcode_5fread_214',['OPCODE_READ',['../_s_p_i_8c.html#ab687b9dc5a7a795edb0455f78235e362',1,'SPI.c']]],
  ['opcode_5fwrite_215',['OPCODE_WRITE',['../_s_p_i_8c.html#a86e0f2e80f3140d6613ece02fa89e569',1,'SPI.c']]]
];
