var searchData=
[
  ['spi_5freceive_174',['SPI_Receive',['../_s_p_i_8c.html#a398be011bdcf3c61d777f4087308784e',1,'SPI_Receive(uint8_t addr, uint8_t device):&#160;SPI.c'],['../_s_p_i_8h.html#a398be011bdcf3c61d777f4087308784e',1,'SPI_Receive(uint8_t addr, uint8_t device):&#160;SPI.c']]],
  ['spi_5ftransmit_175',['SPI_Transmit',['../_s_p_i_8c.html#a9de5405b0431309ebc24fad268aca4c0',1,'SPI_Transmit(uint8_t addr, uint8_t data, uint8_t device):&#160;SPI.c'],['../_s_p_i_8h.html#a9de5405b0431309ebc24fad268aca4c0',1,'SPI_Transmit(uint8_t addr, uint8_t data, uint8_t device):&#160;SPI.c']]],
  ['systemclock_5fconfig_176',['SystemClock_Config',['../main_8c.html#a70af21c671abfcc773614a9a4f63d920',1,'main.c']]]
];
