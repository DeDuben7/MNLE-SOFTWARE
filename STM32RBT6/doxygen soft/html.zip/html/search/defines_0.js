var searchData=
[
  ['adc_5f1_229',['ADC_1',['../main_8h.html#a3d767e16f12a6ee542079f3c9677192c',1,'main.h']]],
  ['adc_5f1_5fgpio_5fport_230',['ADC_1_GPIO_Port',['../main_8h.html#a0fee57e045f7c2879fcc6ac3aa761eac',1,'main.h']]],
  ['adc_5f2_231',['ADC_2',['../main_8h.html#a01ac9d2f00660408bcc8c809020904f9',1,'main.h']]],
  ['adc_5f2_5fgpio_5fport_232',['ADC_2_GPIO_Port',['../main_8h.html#a91b35f3a59cb32bd35e4f23482f6025b',1,'main.h']]],
  ['adc_5f3_233',['ADC_3',['../main_8h.html#a474279f28350114950d862951d72de66',1,'main.h']]],
  ['adc_5f3_5fgpio_5fport_234',['ADC_3_GPIO_Port',['../main_8h.html#a175550ba66542ceae3cc90038d6384e5',1,'main.h']]]
];
