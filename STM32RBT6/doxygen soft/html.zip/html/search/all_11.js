var searchData=
[
  ['waveform_117',['Waveform',['../struct_operator.html#a9a7f4e58c444bd0d2f703ba4977b2c75',1,'Operator']]]
];
