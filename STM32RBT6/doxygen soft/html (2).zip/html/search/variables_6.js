var searchData=
[
  ['i_201',['i',['../group___m_i_d_i.html#ga7e98b8a17c0aad30ba64d47b74e2a6c1',1,'MIDI.c']]],
  ['i_5ftel_202',['i_tel',['../structp_v_c_h.html#ad25d5048a68471f44f4f6d9dfaed3772',1,'pVCH']]]
];
