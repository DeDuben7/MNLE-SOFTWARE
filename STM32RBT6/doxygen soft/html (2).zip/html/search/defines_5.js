var searchData=
[
  ['off_257',['OFF',['../_y_m3812_8h.html#a29e413f6725b2ba32d165ffaa35b01e5',1,'YM3812.h']]],
  ['on_258',['ON',['../_y_m3812_8h.html#ad76d1750a6cdeebd506bfcd6752554d2',1,'YM3812.h']]]
];
