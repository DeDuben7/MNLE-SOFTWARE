var searchData=
[
  ['true_277',['TRUE',['../includes_8h.html#aa8cecfc5c5c054d2875c03e77b7be15d',1,'includes.h']]]
];
