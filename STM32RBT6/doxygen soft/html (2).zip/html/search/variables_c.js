var searchData=
[
  ['receiveflag_220',['ReceiveFlag',['../main_8c.html#a26fa1bdb60287c715227aebc17dc7ef0',1,'main.c']]],
  ['release_221',['Release',['../struct_operator.html#aa9236157a68f4bfc0123e823b34e235c',1,'Operator']]]
];
