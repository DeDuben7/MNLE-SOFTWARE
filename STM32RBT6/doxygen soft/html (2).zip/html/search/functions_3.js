var searchData=
[
  ['spi_5freceive_177',['SPI_Receive',['../group___s_p_i.html#ga398be011bdcf3c61d777f4087308784e',1,'SPI_Receive(uint8_t addr, uint8_t device):&#160;SPI.c'],['../group___s_p_i.html#ga398be011bdcf3c61d777f4087308784e',1,'SPI_Receive(uint8_t addr, uint8_t device):&#160;SPI.c']]],
  ['spi_5ftransmit_178',['SPI_Transmit',['../group___s_p_i.html#ga9de5405b0431309ebc24fad268aca4c0',1,'SPI_Transmit(uint8_t addr, uint8_t data, uint8_t device):&#160;SPI.c'],['../group___s_p_i.html#ga9de5405b0431309ebc24fad268aca4c0',1,'SPI_Transmit(uint8_t addr, uint8_t data, uint8_t device):&#160;SPI.c']]],
  ['systemclock_5fconfig_179',['SystemClock_Config',['../main_8c.html#a70af21c671abfcc773614a9a4f63d920',1,'main.c']]]
];
