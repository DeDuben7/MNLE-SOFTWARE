var searchData=
[
  ['no_5fchip_5fselect_254',['NO_CHIP_SELECT',['../includes_8h.html#a11991e107bfda6239519e5b2663c1281',1,'includes.h']]],
  ['note_5foff_255',['NOTE_OFF',['../_m_i_d_i_8h.html#af6761b4f7bb49361779aa347440fd4ac',1,'MIDI.h']]],
  ['note_5fon_256',['NOTE_ON',['../_m_i_d_i_8h.html#a46dfe6a641c7b31b68e3c2000548dc4c',1,'MIDI.h']]]
];
