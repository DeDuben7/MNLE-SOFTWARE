var searchData=
[
  ['scalinglevel_222',['ScalingLevel',['../struct_operator.html#abcf8d025c2fb0f10560ae48c7774c6df',1,'Operator']]],
  ['spi_5fdata_5frx_223',['SPI_DATA_RX',['../group___s_p_i.html#gafe3f6e8d610c912d39ec5507f0565b92',1,'SPI.c']]],
  ['sustain_224',['Sustain',['../struct_operator.html#a562fcce9ef6ea806f05d2e50c992275d',1,'Operator']]]
];
