var searchData=
[
  ['operator_161',['Operator',['../struct_operator.html',1,'']]]
];
